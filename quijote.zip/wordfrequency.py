from pyspark import SparkContext
import sys
import string

def replace(word):
    for a in string.punctuation+'¿¡«»':
        word = word.replace(a,'')
    return word

def main(sc, filename):
        data = sc.textFile(filename)
        datanp = data.map(replace)
        print (datanp.take(10))

        words_rdd = datanp.flatMap(lambda x: x.split()).map(lambda x:x.strip())
        print (words_rdd.take(10))

        appearances_rdd = words_rdd.map(lambda x: (x.lower(),1))
        print (appearances_rdd.collect())

        result_rdd = appearances_rdd.reduceByKey(lambda x,y: x+y)
        print ('RESULTS------------------')
        print ('words frequency', result_rdd.take(10))

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python3 {0} <file>".format(sys.argv[0]))
    else:
        with SparkContext() as sc:
            sc.setLogLevel("ERROR")
            main(sc, sys.argv[1])